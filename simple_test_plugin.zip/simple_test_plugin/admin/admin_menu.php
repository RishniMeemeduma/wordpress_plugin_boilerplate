<?php // admin menu

defined('ABSPATH') or die('you cannot access to this files');



/************** Top Level function *******************/
// function toplevel_admin_menu(){

// 	add_menu_page('Simple Test',	//plugin Name
// 					'Test',			//menu Item name
// 					'manage_options',	
// 					'testplugin',	// menu slug
// 					'display_settings_page',	// callback function
// 					'dashicons-admin-generic',
// 					10);
// }

// add_action('admin_menu','toplevel_admin_menu');

// /*****************************************************/
/**************** Sub Level Function********************/


function sublevel_admin_menu(){

	add_submenu_page('options-general.php',
						'Simple Test Plugin',
						'Test Plugin',
						'manage_options',
						'Test_plugin',
						'display_settings_page');
}
add_action('admin_menu','sublevel_admin_menu');