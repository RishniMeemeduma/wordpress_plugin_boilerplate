<?php  //setting register functions

defined('ABSPATH') or die('you cannot access to this files');
function setting_link(){

	register_setting('testplugin_options',
					'testplugin_options',
					'testplugin_callback_validate_option');

	add_settings_section('testplugin_section_login',
						'Customize Login Page',
						'testplugin_callback_section_login',
						'Test_plugin');

	add_settings_section('testplugin_section_admin',
						'Customize Admin Page',
						'testplugin_callback_section_admin',
						'Test_plugin');

	add_settings_field('custom_url',
						'Custom URL',
						'textplugin_callback_field_text',
						'Test_plugin',
						'testplugin_section_login',
						['id' => 'custom_url','label' =>'Custom URL for the login logo link']);

	add_settings_field('custom_title',
						'Custom Title',
						'textplugin_callback_field_text',
						'Test_plugin',
						'testplugin_section_login',
						['id' => 'custom_title','label' =>'Custom Title for the login logo link']);

	add_settings_field('custom_style',
						'Custom Style',
						'textplugin_callback_field_radio',
						'Test_plugin',
						'testplugin_section_login',
						['id' => 'custom_style','label' =>'Custom Style for the login logo link']);

	add_settings_field('custom_message',
						'Custom Message',
						'textplugin_callback_field_textarea',
						'Test_plugin',
						'testplugin_section_login',
						['id' => 'custom_message','label' =>'Custom Message for the login logo link']);

	add_settings_field('custom_footer',
						'Custom footer',
						'textplugin_callback_field_text',
						'Test_plugin',
						'testplugin_section_admin',
						['id' => 'custom_footer','label' =>'Custom Footer for the login logo link']);

	add_settings_field('custom_toolbar',
						'Custom Toolbar',
						'textplugin_callback_field_checkbox',
						'Test_plugin',
						'testplugin_section_admin',
						['id' => 'custom_toolbar','label' =>'Custom Toolbar for the login logo link']);

	add_settings_field('custom_scheme',
						'Custom scheme',
						'textplugin_callback_field_select',
						'Test_plugin',
						'testplugin_section_admin',
						['id' => 'custom_scheme','label' =>'Custom scheme for the login logo link']);


}

add_action('admin_init','setting_link');