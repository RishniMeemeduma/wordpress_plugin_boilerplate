<?php  // setting page

defined('ABSPATH') or die('you cannot access to this files');

function display_settings_page(){

	if(! current_user_can('manage_options')) return;

	?>
	<div class='wrap'>
		<h1> <?php echo esc_html(get_admin_page_title());?></h1>
		<form action='options.php' method='POST'>

			<?php
				// output security fields
				settings_fields('testplugin_options');

				//output setting sections
				do_settings_sections('Test_plugin');

				submit_button(); 

			?>
		</form>

	</div>
<?php } ?>