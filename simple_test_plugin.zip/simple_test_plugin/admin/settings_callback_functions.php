<?php //callback functions

defined('ABSPATH') or die('you cannot access to this files');
function testplugin_callback_validate_option($link){

	return $link;

}

function testplugin_callback_section_login(){
	echo '<p>These settings unable you to edit wp login section</p>';
}

function testplugin_callback_section_admin(){
	echo '<p>These settings unable you to edit admin section</p>';
}

function textplugin_callback_field_text($args){

	$options =get_option('testplugin_options' ,textplugin_options_returns());

	$id= isset($args['id']) ? $args['id'] :'';
	$label = isset($args['label']) ? $args['label'] :'';

	$value = isset($options[$id]) ? sanitize_text_field( $options[$id]) : '';

	echo '<input id ="testplugin_options_'. $id .'" name="testplugin_options['.$id .']>" type="text" size="40" value="'.$value.'"<br/>';
	echo '<label for="testplugin_options_'.$id.'">'.$label.'</label>';
}

function textplugin_callback_field_radio($args){

	$options = get_option('testplugin_options' ,textplugin_options_returns());


	$id    = isset( $args['id'] )    ? $args['id']    : '';
	$label = isset( $args['label'] ) ? $args['label'] : '';

	$selected_option = isset( $options[$id] ) ? sanitize_text_field( $options[$id] ) : '';

	$radio_options = array(

		'enable'  => 'Enable custom styles',
		'disable' => 'Disable custom styles'

	);

	foreach ( $radio_options as $value => $label ) {

		$checked = checked( $selected_option === $value, true, false );

		echo '<label><input name="testplugin_options['. $id .']" type="radio" value="'. $value .'"'. $checked .'> ';
		echo '<span>'. $label .'</span></label><br />';

	}
}

function textplugin_callback_field_textarea($args){

$options = get_option( 'testplugin_options', textplugin_options_returns() );

	
	$id    = isset( $args['id'] )    ? $args['id']    : '';

	$label = isset( $args['label'] ) ? $args['label'] : '';

	
	$allowed_tags = wp_kses_allowed_html( 'post' );
	

	$value = isset( $options[$id] ) ? wp_kses( stripslashes_deep( $options[$id] ), $allowed_tags ) : '';

	
	echo '<textarea id="testplugin_options_'. $id .'" name="testplugin_options['. $id .']" rows="5" cols="50">'. $value .'</textarea><br />';

	echo '<label for="testplugin_options_'. $id .'">'. $label .'</label>';

	
}

function textplugin_callback_field_select($args){

	$options =get_option('testplugin_options' ,textplugin_options_returns());

	$id= isset($args['id']) ? $args['id'] :'';
	$label = isset($args['label']) ? $args['label'] :'';

	$selected_option = isset($options[$id]) ? sanitize_text_field( $options[$id]) : '';

	$select_options = array(

		'default'=>'Default',
		'light_blue' => 'Light Blue',
		'red' => 'Red'
		);

	echo '<select id="testplugin_options_'. $id .'" name="testplugin_options_['. $id .']">';

	foreach($select_options as $value => $options){

		$selected =selected($selected_option === $value ,true,false);

		echo '<option value="'.$value.''.$selected.'">'.$options.'</option>';
	}
	echo '</select><label for="testplugin_options_'. $id .'" >'.$label.'</label>';

}

function textplugin_callback_field_checkbox($args){

	$options = get_option( 'testplugin_optionss', textplugin_options_returns() );

	$id    = isset( $args['id'] )    ? $args['id']    : '';
	$label = isset( $args['label'] ) ? $args['label'] : '';

	$checked = isset( $options[$id] ) ? checked( $options[$id], 1, false ) : '';

	echo '<input id="testplugin_options_'. $id .'" name="testplugin_options['. $id .']" type="checkbox" value="1"'. $checked .'> ';
	echo '<label for="testplugin_options_'. $id .'">'. $label .'</label>';

}