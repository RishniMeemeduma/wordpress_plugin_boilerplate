<?php

/*
Plugin Name: Simple Test Plugin
Plugin URI: https://simple_test_plugin.com
Description: This is a simple text plugin
Version: 1.0.0
Author: Rishni Meemeduma
Author URI: https://github.com/RishniMeemeduma
License: GPLv2 or Later
*/

defined('ABSPATH') or die('you cannot access to this files');

function activate(){
	if( ! current_user_can('activate_plugins')) return;

	add_option('myplugin_posts_per_page',10);
	add_option('myplugin_show_welcome_page',true);

}
register_activation_hook(__FILE__,'activate');

function deactivate(){

	//wp_die('you are deactivated');
	if(! current_user_can('activate_plugins')) return;
	flush_rewrite_rules();
}
register_deactivation_hook(__FILE__,'deactivate');

function uninstall(){

	if(! current_user_can('activate_plugins')) return;

	delete_option('myplugin_posts_per_page',10);
	delete_option('myplugin_show_welcome_page',true);
}

register_uninstall_hook(__FILE__,'uninstall');


if(is_admin()){
require_once plugin_dir_path(__FILE__).'admin/admin_menu.php';
require_once plugin_dir_path(__FILE__).'admin/settings.php';

require_once plugin_dir_path(__FILE__).'admin/settings_callback_functions.php';
require_once plugin_dir_path(__FILE__).'admin/settings_register.php';

}

require_once plugin_dir_path(__FILE__).'includes/core-functions.php';

function textplugin_options_returns(){



	return array(
		'custom_url'     => 'https://wordpress.org/',
		'custom_title'   => 'Powered by WordPress',
		'custom_style'   => 'disable',
		'custom_message' => '<p class="custom-message">My custom message</p>',
		'custom_footer'  => 'Special message for users',
		'custom_toolbar' => false,
		'custom_scheme'  => 'default',
	);

}

function enqueue(){

	wp_enqueue_script('myscript',plugins_url('public/js'));
	wp_enqueue_style('mystyle',plugins_url('public/css'));
}
add_action('wp_enqueue_scripts','enqueue');




