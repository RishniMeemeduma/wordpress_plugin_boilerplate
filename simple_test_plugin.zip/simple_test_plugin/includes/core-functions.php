<?php // Test plauign - core functionality

defined( 'ABSPATH') or die('You cannot access to this file');

function myplugin_custom_login_url($url){
	$options= get_option('testplugin_options',textplugin_options_returns());

	if(isset($options['custom_url']) && !empty( $options['custom_url'])){
		$url = esc_url($options['custom_url']);
	}
	return $url;
}
add_filter('login_headerurl','myplugin_custom_login_url');


function myplugin_custom_login_title($title){
	$options= get_option('testplugin_options',textplugin_options_returns());

	if(isset($options['custom_title']) && !empty($options['custom_title'])){
		$title = esc_attr( $options['custom_title']);
	}
	return $title;
}
add_filter('login_headertitle','myplugin_custom_login_title');

function myplugin_custom_login_message($message){

	$options= get_option('testplugin_options',textplugin_options_returns());

	if(isset($options['custom_message']) && !empty($options['custom_message'])){
		$message= wp_kses_post($options['custom_message']). $message;
	}

	return $message;
}
add_filter('login_message','myplugin_custom_login_message');

function myplugin_custom_admin_toolbar(){

	$toolbar = false;
	$options =get_option('testplugin_options',textplugin_options_returns());

	if(isset($options['custom_toolbar']) && !empty($options['custom_toolbar'])){
		$toolbar = (bool) $options['custom_toolbar'];
	}

	if($toolbar){
		global $wp_admin_bar;

		$wp_admin_bar ->remove_menu('comments');
		$wp_admin_bar ->remove_menu('new-content');

	}

}
add_action('wp_before_admin_bar_render','myplugin_custom_admin_toolbar',999);